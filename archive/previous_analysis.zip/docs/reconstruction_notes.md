# Reconstruction and reproducibility notes

## Status

The repository contains a **reconstructed implementation** based on the thesis and Excel workbook.

It is **not** the historical source code used during the thesis. The original code and fitted models were unavailable, so this implementation was rebuilt from the documented methodology (Chapter 3 and Chapter 4 of the thesis) and the available analysis workbook.

## Directly preserved materials

- `docs/thesis_summary.docx` — supplied thesis summary.
- `results/reported_model_performance.csv` — values reported in the supplied workbook.
- `results/reported_feature_importance.csv` — reported SHAP mean-importance values.
- `results/reported_descriptive_summary.csv` — reported descriptive table values.

The patient-level workbook itself is intentionally excluded from GitHub.

## Workbook audit findings

The patient workbook contains 1,600 records and 19 variables, covering 16 hospitals. The final workbook contains zero missing cells. The observed outcome prevalences are:

- `Readmission_30D`: 37.94% (607/1600)
- `Disease_Progression`: 50.75% (812/1600)
- `Complication`: 44.06% (705/1600)

These values are observations from the workbook, not replacements for the thesis.

`Readmission_30D` is used as the reconstruction target because its observed prevalence is close to the prevalence implied by the reported classification metrics.
## Methodology reconstruction

The thesis documents median imputation, winsorization, z-score normalization, one-hot encoding, SMOTE on the training set only, four model families, a 70/30 stratified split, five-fold cross-validation, Optuna tuning, and SHAP analysis.

The reconstructed baseline explicitly implements the preprocessing, 70/30 split, SMOTE, and four model families.
`src/models.py` performs fresh Optuna tuning as part of its model workflow.
`src/predictor_summary.py` uses fixed, recorded XGBoost reconstruction parameters
to regenerate descriptive statistics and holdout SHAP importance from the original
patient records. These are different workflows; neither recovers the original fitted model.

## Reported vs reconstructed metrics

The workbook reports the following XGBoost values:

- Accuracy: 0.939
- Precision: 0.944
- Recall: 0.893
- F1: 0.918
- AUC-ROC: 0.985

The available thesis material does not provide enough historical implementation
detail to determine the precise cause of the discrepancies. Missing target
definitions, preprocessing history, hyperparameters, random seeds, split membership
or fitted models may affect reconstructed model results. These are possible
explanations, not established causes. Model settings cannot change descriptive
statistics calculated directly from the same original patient values.

The user has confirmed that the supplied workbook is the original dataset.
The audit found no complete match for Table 4.12 in 47 diagnostic scenarios.
This does not establish which historical processing or reporting step caused the
differences. See `results/thesis_consistency/consistency_report.md` and
`results/thesis_consistency/documentation_review.md` for the audit evidence.

Run `python src/predictor_summary.py` to generate a proposed replacement table,
an HTML version for viewing/copying, and `correction_record.md` in
`results/raw_patient_summary/`. Submitted values are included only as references
in the correction record; they are never inputs to the statistical calculations.
The original patient workbook and submitted thesis remain unchanged.

The repository therefore keeps reported and reconstructed results separate and does not alter the data or invent code to force agreement.

## Internal inconsistencies found in the thesis materials

The following inconsistencies were found within the thesis and workbook materials;
the documentation review records additional hospital counts and descriptive-table conflicts:

1. **30-day readmission prevalence**: Thesis Table 4.7 reports 542 positive cases (33.9%), while the thesis narrative text (Section 4.3) and the patient-level workbook both report 607 positive cases (37.9%/37.94%). The reconstruction uses the value consistent with the narrative text and the workbook (607, 37.9%), since that is the figure discussed immediately before the main model-comparison results in the thesis.
2. **SHAP feature ranking**: The workbook's `Feature_Importance` sheet (preserved as `results/reported_feature_importance.csv`) ranks Age as the top predictor. However, the thesis's own Table 4.12 and Section 4.5 narrative rank Systolic Blood Pressure and HbA1c as the top two predictors, with Age ranked lower. These two "reported" sources disagree with each other; this reconstruction does not attempt to resolve which one reflects the original analysis, and instead reports its own independently computed SHAP values (`results/reconstructed_feature_importance.csv`) alongside both reported values for comparison.

## Missing hyperparameter values

The thesis references a "Hyperparameter Setting" table (Table 3.x / listed in the table of contents) describing the final Optuna-tuned parameters used for each model. This table's specific values were not recoverable from the supplied thesis document. As a result, the reconstruction performs its own fresh Optuna hyperparameter search (see `src/models.py`) rather than reusing the original tuned values, which were not available. This is a plausible contributor to any remaining gap between reported and reconstructed performance.

## Git history

Any Git history created for this repository begins at the reconstruction. It is not the historical development history of the thesis analysis.
